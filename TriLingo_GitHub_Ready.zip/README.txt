TriLingo Web-App

Dateien:
- index.html
- manifest.webmanifest
- sw.js

Veröffentlichen:
1. ZIP entpacken.
2. Den entpackten Ordner bei einem statischen Webhost hochladen, zum Beispiel Netlify, Cloudflare Pages oder GitHub Pages.
3. Danach die erzeugte HTTPS-Adresse auf dem Handy öffnen.
4. iPhone: Safari > Teilen > Zum Home-Bildschirm.
5. Android: Chrome > Menü > App installieren.

Die App speichert Lernstand, XP, Herzen und Fehlerkarten lokal im Browser.
