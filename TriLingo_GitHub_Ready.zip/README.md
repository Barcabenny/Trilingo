# TriLingo

Dreisprachige Lern-Web-App für Deutsch, Spanisch und Rumänisch.

## GitHub Pages veröffentlichen

1. Auf GitHub ein neues Repository erstellen, z. B. `trilingo`.
2. Alle Dateien aus diesem Ordner in das Repository hochladen.
3. Repository öffnen → Settings → Pages.
4. Unter "Build and deployment":
   - Source: Deploy from a branch
   - Branch: main
   - Folder: / (root)
5. Speichern.
6. Nach wenigen Minuten erscheint die öffentliche Adresse.

Typische Adresse:
`https://DEIN-BENUTZERNAME.github.io/trilingo/`

## Auf dem iPhone installieren

1. Die GitHub-Pages-Adresse in Safari öffnen.
2. Teilen antippen.
3. "Zum Home-Bildschirm" auswählen.

## Enthalten

- Lernpfad
- Spanisch und Rumänisch im Wechsel
- Multiple-Choice-Übungen
- XP und Herzen
- Fehler-Wiederholung
- Karteikarten
- lokale Fortschrittsspeicherung
- installierbare Web-App
